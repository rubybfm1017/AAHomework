class Array
#   # Write an `Array#my_inject` method. If my_inject receives no argument, then
#   # use the first element of the array as the default accumulator.
#   # **Do NOT use the built-in `Array#inject` or `Array#reduce` methods in your 
#   # implementation.**

  def my_inject(accumulator = nil, &prc)
    
    
  end
end

# Define a method `primes(num)` that returns an array of the first "num" primes.
# You may wish to use an `is_prime?` helper method.

def is_prime?(num)
    return false if num < 2
    (2...num).each do |factor|
      return false if num % factor == 0
    end
    true
end

def primes(num)
    result = []
    i = 0 
    while result.length < num 
      result << i if is_prime?(i)
      i += 1
    end
    result
end

# Write a recursive method that returns the first "num" factorial numbers.
# Note that the 1st factorial number is 0!, which equals 1. The 2nd factorial
# is 1!, the 3rd factorial is 2!, etc.

def factorials_rec(num)
    return [] if num == 0
    return [1] if num == 1
    return [1,1] if num == 2
    result = factorials_rec(num - 1)
    result << fac(num - 1)
    result
end

def fac(num)
  return 1 if num == 0
  return 1 if num == 1
  num * fac(num - 1)
end

class Array
#   # Write an `Array#dups` method that will return a hash containing the indices 
#   # of all duplicate elements. The keys are the duplicate elements; the values 
#   # are arrays of their indices in ascending order, e.g.
#   # [1, 3, 4, 3, 0, 3, 0].dups => { 3 => [1, 3, 5], 0 => [4, 6] }

  def dups
    hash = {}
    self.each_with_index do |ele, i|
      if !hash.key?(ele)
        hash[ele] = [i]
      else
        hash[ele] << i
      end
    end
    hash.select {|k,v| v.length >= 2}
  end
end

# class String
#   # Write a `String#symmetric_substrings` method that returns an array of 
#   # substrings that are palindromes, e.g. "cool".symmetric_substrings => ["oo"]
#   # Only include substrings of length > 1.

#   def symmetric_substrings
#   end
# end

class Array
#   # Write an `Array#merge_sort` method; it should not modify the original array.
#   # **Do NOT use the built in `Array#sort` or `Array#sort_by` methods in your 
#   # implementation.**
  
  def merge_sort(&prc)
    return self if self.length <= 1
    mid = self.length / 2
    left = self[0...mid].merge_sort(&prc)
    right = self[mid..-1].merge_sort(&prc)
    Array.merge(left,right,&prc)
  end

  private
  def self.merge(left, right, &prc)
      new_arr = []
      while !left.empty? && !right.empty?
        if prc != nil
          if prc.call(left[0],right[0]) == -1
              new_arr << left.shift
          else
              new_arr << right.shift

          end
        else  
          if left[0] < right[0]
            new_arr << left.shift
          else
             new_arr << right.shift
          end
        end
      end
      new_arr + left + right
  end
end
